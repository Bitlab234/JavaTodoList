package Models;

import java.time.LocalDate;

public class Task {
    private static int nextId = 1;

    private final int id;
    private String name;
    private String description;
    private LocalDate dueDate;
    private Status status;

    public enum Status {NOT_STARTED, IN_PROGRESS, DONE};

    public Task(String name, String description, LocalDate dueDate) {
        this.id = nextId++;
        this.name = name;
        this.description = description;
        this.dueDate = dueDate;
        this.status = Status.NOT_STARTED;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
