package org.example;

import Controllers.Controller;
import Repositories.Repository;
import Services.Service;

public class App {
    public static void main(String[] args) {
        Repository repository = new Repository();
        Service service = new Service();
        Controller controller = new Controller(service);

        controller.start();
    }
}
