package Repositories;

import Models.Task;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;

public class Repository {
    private final ArrayList<Task> Tasks = new ArrayList<>();

    public void addTask (Task newTask) {
        Tasks.add(newTask);
    }

    public ArrayList<Task> getAllTasks () {
        return new ArrayList<>(Tasks);
    }

    public Optional<Task> getTaskByName(String name) {
        return Tasks.stream()
                .filter(task -> task.getName().equalsIgnoreCase(name))
                .findFirst();
    }

    public boolean removeTaskByName(String name) {
        return Tasks.removeIf(task -> task.getName().equalsIgnoreCase(name));
    }

    public ArrayList<Task> filterTasksByStatus(Task.Status status) {
        ArrayList<Task> result = new ArrayList<>();
        for (Task task : Tasks) {
            if (task.getStatus() == status) {
                result.add(task);
            }
        }
        return result;
    }

    public ArrayList<Task> getAllTasksSortedByStatus() {
        ArrayList<Task> sortedTasks = new ArrayList<>(Tasks);
        sortedTasks.sort(Comparator.comparing(Task::getStatus));
        return sortedTasks;
    }

    public ArrayList<Task> getAllTasksSortedByDueDate() {
        ArrayList<Task> sortedTasks = new ArrayList<>(Tasks);
        sortedTasks.sort(Comparator.comparing(Task::getDueDate));
        return sortedTasks;
    }
}
