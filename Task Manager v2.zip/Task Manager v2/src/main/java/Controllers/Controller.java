package Controllers;

import Models.Task;
import Services.Service;

import java.time.LocalDate;
import java.util.Scanner;

public class Controller {
    private final Service Service;

    public Controller(Service service) {
        Service = service;
    }

    public void start() {
        System.out.println("Добро пожаловать в менеджер задач. Список команд:");
        System.out.println("\n'add'    - Добавить новую задачу;");
        System.out.println("'list'   - Показать задачи;");
        System.out.println("'edit'   - Редактировать существующую задачу;");
        System.out.println("'delete' - Удалить задачу;");
        System.out.println("'filter' - Показать задачи с определенным статусом;");
        System.out.println("'sort'   - Отсортировать задачи;");
        System.out.println("'exit'   - Завершить работу приложения.\n");
        consoleListener();
    }

    public void handler_command(String command) {
        Scanner scanner = new Scanner(System.in);
        switch (command) {
            case "add":
                System.out.println("Enter the task name: ");
                String name_command = scanner.nextLine().trim();

                System.out.println("Enter the task description: ");
                String description_command = scanner.nextLine().trim();

                System.out.println("Enter due date in format: yyyy-mm-dd: ");
                LocalDate dueDate = LocalDate.parse(scanner.nextLine());

                Task newTask = new Task(name_command, description_command, dueDate);
                Service.add_task(newTask);
                break;
            case "list":
                Service.printAllTasks();
                break;
            case "edit":
                System.out.println("Choose the task: ");
                Service.printAllIdAndNameOfTasks();
                String name_task = scanner.nextLine().trim();
                System.out.println("Select the column to be edited: \nname\ndescription\ndue date\nstatus");
                String column_task = scanner.nextLine().trim();
                System.out.println("Enter new value: ");
                String newValue = scanner.nextLine().trim();
                Service.editTask(name_task, column_task, newValue);
                break;
            case "delete":
                System.out.println("Choose the task: ");
                Service.printAllIdAndNameOfTasks();
                String nameTask = scanner.nextLine().trim();
                Service.removeTask(nameTask);
                break;
            case "filter":
                System.out.println("Select the column to be filtered: \nafter due date\nbefore due date\nstatus");
                String column = scanner.nextLine().trim();
                System.out.println("Choose the status: NOT_STARTED, IN_PROGRESS, DONE");
                String status = scanner.nextLine().trim();
                Service.filterTasks(column, status);
                break;
            case "sort":
                System.out.println("Select the column to be sorted: \ndate\nstatus");
                String sortChoice = scanner.nextLine();
                if (sortChoice.equals("status")) {
                    Service.sortTasks("status");
                } else if (sortChoice.equals("date")) {
                    Service.sortTasks("date");
                } else {
                    System.out.println("Incorrect choice");
                }
                break;
            case "exit":
                break;
        }
    }

    public void consoleListener(){
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("command: ");
            String command = scanner.nextLine().trim();
            handler_command(command);
        }
    }
}
