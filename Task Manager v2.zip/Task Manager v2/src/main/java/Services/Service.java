package Services;

import Models.Task;
import Repositories.Repository;

import java.util.ArrayList;

public class Service {
    Repository repo = new Repository();

    public void add_task (Task newTask) {
        repo.addTask(newTask);
    }

    public void printAllTasks () {
        System.out.println("\n  All tasks: ");
        for (Task task : repo.getAllTasks()) {
            System.out.printf(task.getId() + " - " + task.getName() + "\n");
            System.out.println(task.getDescription());
            System.out.println(task.getDueDate());
            System.out.println(task.getStatus());
        }

        System.out.println("--------------------------------------------------------------\n");
    }

    public void printAllIdAndNameOfTasks() {
        System.out.println("\n  All tasks: ");
        for (Task task : repo.getAllTasks()) {
            System.out.printf(task.getId() + " - " + task.getName() + "\n");
        }
    }

    public void editTask (String name_task, String column_task, String newValue) {
        Task task = repo.getTaskByName(name_task).orElse(null);

        if(task == null)
        {
            System.out.println("The task is not found");
        }

        switch (column_task) {
            case "name":
                task.setName(newValue);
                break;
            case "description":
                task.setDescription(newValue);
                break;
            case "due date":
                break;
        }
    }

    public void filterTasks (String column, String status) {
        switch (column) {
            case "status":
                Task.Status statusEnum = Task.Status.valueOf(status.toUpperCase());
                ArrayList<Task> filteredTasks = repo.filterTasksByStatus(statusEnum);
                printFilteredTasks(filteredTasks);
        }
    }

    private void printFilteredTasks(ArrayList<Task> tasks) {
        System.out.println("Filtered tasks: ");
        for (Task task : tasks) {
            System.out.printf(task.getId() + " - " + task.getName() + "\n");
            System.out.println(task.getDescription());
            System.out.println(task.getDueDate());
            System.out.println(task.getStatus());
        }

        System.out.println("--------------------------------------------------------------\n");
    }

    public void sortTasks(String sortBy) {
        ArrayList<Task> sortedTasks;

        switch (sortBy.toLowerCase()) {
            case "status":
                sortedTasks = repo.getAllTasksSortedByStatus();
                break;
            case "date":
                sortedTasks = repo.getAllTasksSortedByDueDate();
                break;
            default:
                throw new IllegalArgumentException("Unsupported parameter");
        }

        printSortedTasks(sortedTasks);
    }

    private void printSortedTasks(ArrayList<Task> tasks) {
        System.out.println("Sorted tasks: ");
        for (Task task : tasks) {
            System.out.printf(task.getId() + " - " + task.getName() + "\n");
            System.out.println(task.getDescription());
            System.out.println(task.getDueDate());
            System.out.println(task.getStatus());
        }

        System.out.println("--------------------------------------------------------------\n");
    }

    public void removeTask(String nameTask) {
        repo.removeTaskByName(nameTask);
    }
}
